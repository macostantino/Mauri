"""
Generador de echadas Full Color — imposición offset (rotativa, formato tabloide)
Ejecutar:  streamlit run app.py

La app CALCULA cada echada con su propio motor (echadas/generador.py): tiradas, pliegos F/A,
LADO 10/13, cuadrantes ALTO/BAJO y la página de cada posición. El Excel de plantillas es
opcional y se usa solamente para COMPARAR lo generado contra lo que ya existe.
"""
from __future__ import annotations

import hashlib
import os
import re
from datetime import datetime
from pathlib import Path

import pandas as pd
import streamlit as st

from echadas.catalogo import CATALOGO
from echadas.dibujo import tirada_drawing, tirada_titulo
from echadas.excel import build_xlsx
from echadas.generador import FIGURAS, Cuerpo, figuras_por_defecto, generar, parse_config, plan_tiradas
from echadas.pdf import Job, build_pdf
from echadas.render import to_svg
from echadas.tablas import composicion, grilla, posiciones

APP_DIR = Path(__file__).resolve().parent
CACHE_DIR = APP_DIR / ".cache"

st.set_page_config(page_title="Generador de echadas", layout="wide", initial_sidebar_state="expanded")
st.markdown("""
<style>
  .block-container {padding-top: 1.5rem; max-width: 1450px;}
  .band-head {background: rgba(128,128,128,.10); border-left: 4px solid #B3261E; padding: .45rem .8rem;
              margin: 1.1rem 0 .5rem; border-radius: 4px;}
  .band-head b {font-size: 1.02rem;} .band-head div {opacity:.75; font-size:.85rem;}
  .plan {background:#fff; border:1px solid rgba(128,128,128,.35); border-radius:6px; padding:10px; overflow-x:auto;}
  .verdict {padding:.8rem 1rem; border-radius:8px; font-weight:600; margin:.4rem 0 1rem;}
  .ok {background:#E6F4EA; color:#0D652D; border:1px solid #A8DAB5;}
  .bad {background:#FCE8E6; color:#A50E0E; border:1px solid #F4B4AE;}
  .na {background:rgba(128,128,128,.10); border:1px solid rgba(128,128,128,.3);}
  .colhead {font-weight:600; opacity:.8; margin-bottom:.3rem;}
</style>
""", unsafe_allow_html=True)


def safe(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "-", s).strip("-")


def default_xlsx():
    env = os.environ.get("ECHADAS_XLSX")
    if env and Path(env).exists():
        return Path(env)
    found = sorted(APP_DIR.glob("Plantillas*Echadas*.xlsx"))
    return found[-1] if found else None


@st.cache_resource(show_spinner="Leyendo el Excel de referencia (solo para comparar)…")
def get_library(path: str, stamp: float):
    from echadas.loader import load_library_cached
    return load_library_cached(path, CACHE_DIR)


def nombres_por_defecto(n: int) -> list[str]:
    if n == 1:
        return ["Único"]
    return ["Tapa"] + [f"Suple {i}" for i in range(1, n)]


# --------------------------------------------------------------------------- #
# Barra lateral
# --------------------------------------------------------------------------- #
with st.sidebar:
    st.header("Datos del trabajo")
    job = Job(
        publicacion=st.text_input("Publicación / Producto"),
        edicion=st.text_input("Edición / Fecha", value=datetime.now().strftime("%d/%m/%Y")),
        orden=st.text_input("Orden de trabajo (OT)"),
        responsable=st.text_input("Responsable"),
        destino=st.text_input("Destino / Sección", placeholder="Impresión, Corte, Expedición…"),
        observaciones=st.text_area("Observaciones para taller", height=80),
    )
    st.header("Exportación")
    c1, c2 = st.columns(2)
    pdf_page = c1.selectbox("Papel", ["A4", "A3"])
    pdf_orient = c2.selectbox("Orientación", ["Vertical", "Horizontal"])
    opt_grid = st.checkbox("PDF: tablas de posiciones por pliego", value=True)
    opt_sigs = st.checkbox("PDF: casilleros de firma", value=True)
    opt_img = st.checkbox("Excel: incluir imagen del plano", value=True)
    opt_rep = st.checkbox("Tiradas de 8 págs.: marcar REPITE", value=True)
    out_dir = st.text_input("Carpeta de red para envío (opcional)", value=os.environ.get("ECHADAS_SALIDA", ""),
                            placeholder=r"\\servidor\imposicion  o  C:\Planos")

    st.header("Control (opcional)")
    up = st.file_uploader("Excel de plantillas de referencia", type=["xlsx"],
                          help="No se usa para generar: solo para comparar la echada generada.")
    if up is not None:
        data = up.getvalue()
        CACHE_DIR.mkdir(exist_ok=True)
        ref_path = CACHE_DIR / f"ref_{hashlib.sha1(data).hexdigest()[:12]}.xlsx"
        if not ref_path.exists():
            ref_path.write_bytes(data)
    else:
        ref_path = default_xlsx()
    comparar_auto = st.checkbox("Comparar automáticamente", value=ref_path is not None,
                                disabled=ref_path is None)
    st.caption(f"Referencia: **{ref_path.name if up is None and ref_path else (up.name if up else '—')}**")

# --------------------------------------------------------------------------- #
# Entrada
# --------------------------------------------------------------------------- #
st.title("Generador de echadas Full Color")
st.caption("El motor calcula tiradas, pliegos F/A, LADO 10/13, cuadrantes ALTO/BAJO y la página de cada "
           "posición. El Excel de referencia solo se usa para comparar.")

c_tot, c_modo, c_cfg = st.columns([1, 1.3, 2.7])
total = c_tot.number_input("Total de páginas", min_value=4, max_value=400, step=4, value=24)
modo = c_modo.radio("Combinación", ["Catálogo estándar", "Nueva / personalizada"], horizontal=False)
cat = [(t, cfg, ref) for (t, cfg, ref) in CATALOGO if t == total]
if modo == "Catálogo estándar":
    if cat:
        elegido = c_cfg.selectbox(f"Cuerpos ({len(cat)} combinación/es estándar para {total} págs.)", cat,
                                  format_func=lambda x: f"{x[1]}     (plantilla de referencia {x[2]})")
        cfg_text = elegido[1]
    else:
        c_cfg.warning(f"No hay combinaciones estándar de {total} págs. Use «Nueva / personalizada».")
        cfg_text = str(total)
else:
    cfg_text = c_cfg.text_input("Cuerpos, en orden (de afuera hacia adentro)", value=str(total),
                                help="Ejemplos: 24 · 20+4 · 36+24+4+4+4. Cada cuerpo en múltiplos de 4.")

try:
    paginas = parse_config(cfg_text)
except ValueError as ex:
    st.error(str(ex))
    st.stop()
if sum(paginas) != total:
    st.error(f"Los cuerpos suman {sum(paginas)} págs. pero el total indicado es {total}.")
    st.stop()

# editor de cuerpos (nombre + figura)
key = "cuerpos_" + "+".join(map(str, paginas))
df0 = pd.DataFrame({"Cuerpo": nombres_por_defecto(len(paginas)), "Figura": figuras_por_defecto(len(paginas)),
                    "Págs.": paginas})
with st.expander("Cuerpos: nombres y figuras (editable)", expanded=len(paginas) > 1):
    df = st.data_editor(
        df0, key=key, hide_index=True, width="stretch", num_rows="fixed",
        column_config={
            "Cuerpo": st.column_config.TextColumn("Cuerpo", help="Nombre que aparece en el plano"),
            "Figura": st.column_config.SelectboxColumn("Figura", options=FIGURAS, required=True),
            "Págs.": st.column_config.NumberColumn("Págs.", disabled=True),
        })
    tir_txt = st.text_input("Tiradas (opcional, avanzado)", value="",
                            placeholder="Automático: " + "+".join(map(str, plan_tiradas(total))),
                            help="Por defecto se llenan tiradas de 32 págs. y la última lleva el resto.")

cuerpos = [Cuerpo(int(r["Págs."]), str(r["Cuerpo"] or f"Cuerpo {i + 1}"), str(r["Figura"]))
           for i, r in df.reset_index(drop=True).iterrows()]
try:
    tiradas = parse_config(tir_txt) if tir_txt.strip() else None
    ech = generar(cuerpos, tiradas)
except ValueError as ex:
    st.error(str(ex))
    st.stop()

# --------------------------------------------------------------------------- #
# Comparación (opcional)
# --------------------------------------------------------------------------- #
cmp = None          # (entry, sel, resultado)
control_txt = None
if comparar_auto and ref_path is not None:
    from echadas.comparar import buscar_en_indice, comparar, extraer_plantilla, tiradas_de_indice
    from echadas.report import select
    lib = get_library(str(ref_path), ref_path.stat().st_mtime)
    matches = buscar_en_indice(lib, paginas)
    if matches:
        entry = matches[0]
        t_idx = tiradas_de_indice(entry)
        ech_cmp = ech if (t_idx is None or t_idx == [t.paginas for t in ech.tiradas]) else generar(cuerpos, t_idx)
        sel = select(lib, entry)
        res = comparar(ech_cmp, extraer_plantilla(sel))
        cmp = (entry, sel, res)
        control_txt = (f"IDÉNTICA a la plantilla {entry.folio} ({res.posiciones} posiciones)" if res.identica else
                       f"DIFIERE de la plantilla {entry.folio}: {len(res.diferencias)} de {res.posiciones} posiciones")
    else:
        control_txt = "Echada nueva: no existe en las plantillas de referencia."

# --------------------------------------------------------------------------- #
# Resumen + exportación
# --------------------------------------------------------------------------- #
m = st.columns(5)
m[0].metric("Total", f"{ech.total} págs.")
m[1].metric("Cuerpos", str(len(ech.cuerpos)))
m[2].metric("Tiradas", str(len(ech.tiradas)))
m[2].caption(" | ".join(str(t.paginas) for t in ech.tiradas))
m[3].metric("Pliegos", str(sum(len(t.webs) for t in ech.tiradas)))
if cmp:
    m[4].metric("Control", "Idéntica" if cmp[2].identica else f"{cmp[2].porcentaje:.0f}% coincide")
    m[4].caption(f"vs. plantilla {cmp[0].folio}")
elif control_txt:
    m[4].metric("Control", "Nueva")
for a in ech.avisos:
    st.warning(a)

base = safe(f"Echada_{ech.total}p_{ech.config.replace('+', '-')}" + (f"_OT{job.orden}" if job.orden else "")
            + f"_{datetime.now():%Y%m%d}")
with st.container(border=True):
    e1, e2, e3 = st.columns([1, 1, 1.4])
    pdf = build_pdf(ech, job, page=pdf_page, orientation=pdf_orient, include_grid=opt_grid,
                    include_signatures=opt_sigs, repite_8=opt_rep, control=control_txt)
    xls = build_xlsx(ech, job, include_image=opt_img, repite_8=opt_rep, control=control_txt,
                     diferencias=cmp[2].diferencias if cmp else None)
    e1.download_button("Descargar PDF para taller", pdf, file_name=f"{base}.pdf", mime="application/pdf",
                       type="primary", width="stretch")
    e2.download_button("Descargar Excel estructurado", xls, file_name=f"{base}.xlsx", width="stretch",
                       mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    if e3.button("Enviar a carpeta de red (PDF + Excel)", width="stretch", disabled=not out_dir):
        try:
            dest = Path(out_dir)
            dest.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now().strftime("%H%M%S")
            (dest / f"{base}_{stamp}.pdf").write_bytes(pdf)
            (dest / f"{base}_{stamp}.xlsx").write_bytes(xls)
            st.success(f"Guardado en {dest}")
        except Exception as ex:
            st.error(f"No se pudo guardar en '{out_dir}': {ex}")

# --------------------------------------------------------------------------- #
# Pestañas
# --------------------------------------------------------------------------- #
tab_plan, tab_comp, tab_cmp, tab_val = st.tabs(
    ["Plano generado", "Composición y posiciones", "Comparar con plantilla", "Validación general"])

with tab_plan:
    for t in reversed(ech.tiradas):
        titulo, detalle = tirada_titulo(ech, t)
        rep = "  ·  REPITE" if (opt_rep and t.formato == 8) else ""
        st.markdown(f"<div class='band-head'><b>{titulo}{rep}</b><div>{detalle}</div></div>", unsafe_allow_html=True)
        d = tirada_drawing(ech, t, opt_rep)
        st.markdown(f"<div class='plan'>{to_svg(d, max_width=int(d.width * 1.35))}</div>", unsafe_allow_html=True)
    st.caption("Las tiradas se muestran como en las planillas: de la última a la primera (tapa). "
               "ALTO/BAJO = cuadrante · F/A = pliego · LADO 10/13 = caras.")

with tab_comp:
    st.subheader("Composición")
    st.dataframe(pd.DataFrame(composicion(ech)), hide_index=True, width="stretch")
    st.subheader("Posiciones por pliego")
    for t in ech.tiradas:
        for web in t.webs:
            headers, rows = grilla(ech, t.numero, web)
            st.markdown(f"**Tirada {t.numero} · pliego {web}**")
            st.dataframe(pd.DataFrame(rows, columns=headers, index=["Superior", "Inferior"]), width="stretch")
    with st.expander("Tabla completa de posiciones"):
        st.dataframe(pd.DataFrame(posiciones(ech)), hide_index=True, width="stretch")

with tab_cmp:
    if ref_path is None:
        st.info("Cargue el Excel de plantillas en la barra lateral para comparar.")
    elif not comparar_auto:
        st.info("Active «Comparar automáticamente» en la barra lateral.")
    elif cmp is None:
        st.markdown("<div class='verdict na'>Esta combinación no figura en las plantillas de referencia: "
                    "es una echada nueva, no hay contra qué compararla.</div>", unsafe_allow_html=True)
    else:
        entry, sel, res = cmp
        cls = "ok" if res.identica else "bad"
        txt = (f"IDÉNTICA a la plantilla {entry.folio} («{sel.sheet.name.strip()}»): coinciden las "
               f"{res.posiciones} posiciones (página y cuerpo)." if res.identica else
               f"DIFIERE de la plantilla {entry.folio} («{sel.sheet.name.strip()}»): "
               f"{len(res.diferencias)} de {res.posiciones} posiciones distintas.")
        st.markdown(f"<div class='verdict {cls}'>{txt}</div>", unsafe_allow_html=True)
        if res.mapeo:
            st.markdown("**Correspondencia de figuras** (el Excel usa símbolos distintos según la hoja):")
            st.dataframe(pd.DataFrame([{"Figura en el Excel": k, "Cuerpo generado": v} for k, v in res.mapeo.items()]),
                         hide_index=True)
        if res.diferencias:
            st.markdown("**Diferencias**")
            st.dataframe(pd.DataFrame(res.diferencias), hide_index=True, width="stretch")
        st.markdown("**Lado a lado**")
        from echadas.render import build_band
        n = len(sel.bands)
        for bi, band in enumerate(sel.bands):
            tnum = (n - bi) if entry.kind == "tiradas" else 1
            t = ech.tiradas[tnum - 1] if tnum <= len(ech.tiradas) else None
            a, b = st.columns(2)
            a.markdown(f"<div class='colhead'>Generada · Tirada {tnum}</div>", unsafe_allow_html=True)
            if t is not None:
                d = tirada_drawing(ech, t, opt_rep)
                a.markdown(f"<div class='plan'>{to_svg(d, max_width=int(d.width * 1.2))}</div>",
                           unsafe_allow_html=True)
            b.markdown(f"<div class='colhead'>Excel · {band.title or 'sección ' + str(band.number)}</div>",
                       unsafe_allow_html=True)
            b.markdown(f"<div class='plan'>{to_svg(build_band(sel.sheet, band))}</div>", unsafe_allow_html=True)

with tab_val:
    st.write("Genera **todas** las combinaciones del índice con el motor y las compara, una por una, "
             "contra su plantilla del Excel.")
    if ref_path is None:
        st.info("Cargue el Excel de plantillas en la barra lateral.")
    elif st.button("Validar todas las combinaciones", type="primary"):
        from echadas.comparar import comparar_entrada
        lib = get_library(str(ref_path), ref_path.stat().st_mtime)
        filas, prog = [], st.progress(0.0)
        for i, entry in enumerate(lib.entries):
            try:
                ech_v, sel_v, r = comparar_entrada(lib, entry)
                filas.append({"Plantilla": entry.folio, "Total": entry.total, "Cuerpos": ech_v.config,
                              "Tiradas": " | ".join(str(t.paginas) for t in ech_v.tiradas),
                              "Resultado": "Idéntica" if r.identica else "Difiere",
                              "Coinciden": f"{r.coinciden}/{r.posiciones}",
                              "Detalle": "" if r.identica else "; ".join(
                                  f"T{d['Tirada']} {d['Web']} {d['Lado']} col{d['Columna']} {d['Fila']}: "
                                  f"gen {d['Generada']} / Excel {d['Excel']}" for d in r.diferencias[:4])})
            except Exception as ex:
                filas.append({"Plantilla": entry.folio, "Total": entry.total, "Cuerpos": entry.config,
                              "Resultado": "Error", "Detalle": str(ex)})
            prog.progress((i + 1) / len(lib.entries))
        dfv = pd.DataFrame(filas)
        n_ok = int((dfv["Resultado"] == "Idéntica").sum())
        st.markdown(f"<div class='verdict {'ok' if n_ok == len(dfv) else 'bad'}'>{n_ok} de {len(dfv)} "
                    f"combinaciones generadas son idénticas a su plantilla.</div>", unsafe_allow_html=True)
        st.dataframe(dfv.sort_values("Resultado"), hide_index=True, width="stretch")
