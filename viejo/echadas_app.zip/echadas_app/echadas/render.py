"""
Lista de dibujo (display list) de una región de hoja-plantilla.

Una sola geometría alimenta a los dos motores de salida (SVG en pantalla y
ReportLab en PDF), así lo que se ve es exactamente lo que se imprime.
Unidades: píxeles a 96 dpi, origen arriba-izquierda de la región.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from html import escape

from .loader import Band, SheetModel

FONT_STACK = "Arial, Helvetica, sans-serif"

BORDER_W = {"hair": 0.5, "thin": 1.0, "medium": 2.0, "thick": 3.0, "double": 2.5,
            "dashed": 1.0, "dotted": 1.0, "mediumDashed": 2.0, "dashDot": 1.0,
            "mediumDashDot": 2.0, "dashDotDot": 1.0, "mediumDashDotDot": 2.0, "slantDashDot": 2.0}
BORDER_DASH = {"dashed": (4, 2), "dotted": (1, 2), "mediumDashed": (6, 3), "dashDot": (6, 2, 1, 2),
               "mediumDashDot": (6, 2, 1, 2), "dashDotDot": (6, 2, 1, 2, 1, 2),
               "mediumDashDotDot": (6, 2, 1, 2, 1, 2), "slantDashDot": (6, 2, 1, 2)}

# rectángulo de texto de cada figura (fracciones de w/h), según presets de Office
TEXT_RECT = {
    "ellipse": (0.146, 0.146, 0.854, 0.854),
    "triangle": (0.25, 0.5, 0.75, 1.0),
    "roundRect": (0.05, 0.05, 0.95, 0.95),
    "heptagon": (0.15, 0.2, 0.85, 0.85),
    "hexagon": (0.2, 0.1, 0.8, 0.9),
    "pentagon": (0.2, 0.3, 0.8, 0.9),
    "octagon": (0.15, 0.15, 0.85, 0.85),
    "diamond": (0.25, 0.25, 0.75, 0.75),
}


@dataclass
class Drawing:
    width: float
    height: float
    ops: list = field(default_factory=list)


def shape_points(geom, x, y, w, h):
    """Polígono para figuras sin primitiva propia (None = usar primitiva)."""
    if geom == "triangle":
        return [(x + w / 2, y), (x + w, y + h), (x, y + h)]
    if geom == "hexagon":
        return [(x, y + h / 2), (x + w * 0.25, y), (x + w * 0.75, y), (x + w, y + h / 2),
                (x + w * 0.75, y + h), (x + w * 0.25, y + h)]
    if geom == "diamond":
        return [(x + w / 2, y), (x + w, y + h / 2), (x + w / 2, y + h), (x, y + h / 2)]
    if geom == "octagon":
        k = 0.29
        return [(x + w * k, y), (x + w * (1 - k), y), (x + w, y + h * k), (x + w, y + h * (1 - k)),
                (x + w * (1 - k), y + h), (x + w * k, y + h), (x, y + h * (1 - k)), (x, y + h * k)]
    if geom in ("heptagon", "pentagon"):
        n = 7 if geom == "heptagon" else 5
        pts = [(math.cos(-math.pi / 2 + 2 * math.pi * i / n), math.sin(-math.pi / 2 + 2 * math.pi * i / n))
               for i in range(n)]
        minx, maxx = min(p[0] for p in pts), max(p[0] for p in pts)
        miny, maxy = min(p[1] for p in pts), max(p[1] for p in pts)
        return [(x + (px - minx) / (maxx - minx) * w, y + (py - miny) / (maxy - miny) * h) for px, py in pts]
    return None


def _wrap(text, width_px, size_px):
    avg = size_px * 0.55
    max_chars = max(1, int(width_px / avg))
    out = []
    for para in text.split("\n"):
        words, line = para.split(" "), ""
        for wd in words:
            cand = (line + " " + wd).strip()
            if len(cand) <= max_chars or not line:
                line = cand
            else:
                out.append(line)
                line = wd
        out.append(line)
    return out


def build_region(sm: SheetModel, r1: int, r2: int, c0: int | None = None, c1: int | None = None) -> Drawing:
    c0 = c0 or sm.min_col
    c1 = c1 or sm.max_col
    # figuras ancladas en la región pueden extenderla hacia abajo/derecha
    region_shapes = [s for s in sm.shapes if r1 <= s.r1 <= r2]
    r_end = sm.extent(r1, r2)
    c_end = max([c1] + [s.c2 for s in region_shapes])
    x0, y0 = sm.col_x[c0], sm.row_y[r1]
    width = sm.col_x[min(c_end + 1, max(sm.col_x))] - x0
    height = sm.row_y[min(r_end + 1, max(sm.row_y))] - y0
    for s in region_shapes:
        width = max(width, s.x + s.w - x0 + 2)
        height = max(height, s.y + s.h - y0 + 2)
    d = Drawing(width=width, height=height)
    ops = d.ops

    in_region = {k: c for k, c in sm.cells.items() if r1 <= k[0] <= r_end and c0 <= k[1] <= c_end}

    # 1) rellenos
    for (r, c), cell in in_region.items():
        m = sm.merge_of.get((r, c))
        if m and (m.r1, m.c1) != (r, c):
            continue
        if cell.fill:
            x, y, w, h = sm.cell_rect(r, c)
            ops.append(("rect", x - x0, y - y0, w, h, cell.fill))

    # 2) textos
    for (r, c), cell in in_region.items():
        if not cell.text:
            continue
        m = sm.merge_of.get((r, c))
        if m and (m.r1, m.c1) != (r, c):
            continue
        x, y, w, h = sm.cell_rect(r, c)
        x -= x0
        y -= y0
        size_px = cell.size * 4 / 3
        ha = cell.h_align
        if ha in ("center", "centerContinuous", "distributed", "justify"):
            anchor, tx = "middle", x + w / 2
        elif ha == "right" or (ha in (None, "general") and cell.is_number):
            anchor, tx = "end", x + w - 3
        else:
            anchor, tx = "start", x + 3
        lines = _wrap(cell.text, w - 4, size_px) if cell.wrap else cell.text.split("\n")
        lh = size_px * 1.15
        total = lh * len(lines)
        va = cell.v_align
        if va == "top":
            base = y + size_px * 0.95
        elif va in ("center", "distributed", "justify"):
            base = y + h / 2 - total / 2 + size_px * 0.9
        else:
            base = y + h - 3 - (len(lines) - 1) * lh - size_px * 0.15
        for i, ln in enumerate(lines):
            ops.append(("text", tx, base + i * lh, ln, size_px, cell.bold, cell.italic,
                        cell.color or "#000000", anchor))

    # 3) bordes
    for (r, c), cell in in_region.items():
        if not cell.borders:
            continue
        m = sm.merge_of.get((r, c))
        x = sm.col_x[c] - x0
        y = sm.row_y[r] - y0
        w = sm.col_px.get(c, 64)
        h = sm.row_px.get(r, 17)
        for side, (style, color) in cell.borders.items():
            if m:
                if side == "left" and c != m.c1:
                    continue
                if side == "right" and c != m.c2:
                    continue
                if side == "top" and r != m.r1:
                    continue
                if side == "bottom" and r != m.r2:
                    continue
            bw = BORDER_W.get(style, 1.0)
            dash = BORDER_DASH.get(style)
            if side == "left":
                seg = (x, y, x, y + h)
            elif side == "right":
                seg = (x + w, y, x + w, y + h)
            elif side == "top":
                seg = (x, y, x + w, y)
            else:
                seg = (x, y + h, x + w, y + h)
            ops.append(("line", *seg, bw, color, dash))

    # 4) figuras (van por encima de las celdas, como en Excel)
    for s in region_shapes:
        ops.append(("shape", s.geom, s.x - x0, s.y - y0, s.w, s.h, s.fill, s.line, s.line_w * 4 / 3,
                    s.clean_text, s.font_size * 4 / 3, s.bold, s.text_color))
    return d


def build_band(sm: SheetModel, band: Band) -> Drawing:
    return build_region(sm, band.r1, band.r2)


# --------------------------------------------------------------------------- #
# SVG
# --------------------------------------------------------------------------- #
def _shape_text_pos(geom, x, y, w, h, size_px):
    l, t, r, b = TEXT_RECT.get(geom, (0, 0, 1, 1))
    tx = x + w * (l + r) / 2
    ty = y + h * (t + b) / 2 + size_px * 0.36
    return tx, ty


def to_svg(d: Drawing, max_width: int | None = None, title: str = "") -> str:
    W, H = math.ceil(d.width) + 2, math.ceil(d.height) + 2
    style = f"max-width:{max_width or W}px;width:100%;height:auto;background:#fff"
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-1 -1 {W} {H}" '
           f'style="{style}" font-family="{FONT_STACK}" role="img">']
    if title:
        out.append(f"<title>{escape(title)}</title>")
    for op in d.ops:
        kind = op[0]
        if kind == "rect":
            _, x, y, w, h, fill = op
            out.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" fill="{fill}"/>')
        elif kind == "line":
            _, x1, y1, x2, y2, bw, color, dash = op
            da = f' stroke-dasharray="{",".join(str(v) for v in dash)}"' if dash else ""
            out.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{color}" '
                       f'stroke-width="{bw}" stroke-linecap="square"{da}/>')
        elif kind == "text":
            _, x, y, txt, size, bold, italic, color, anchor = op
            out.append(f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size:.1f}" '
                       f'font-weight="{"bold" if bold else "normal"}" '
                       f'font-style="{"italic" if italic else "normal"}" fill="{color}" '
                       f'text-anchor="{anchor}" xml:space="preserve">{escape(txt)}</text>')
        elif kind == "shape":
            _, geom, x, y, w, h, fill, line, lw, txt, size, bold, tcolor = op
            f = fill or "none"
            st = line or "none"
            common = f'fill="{f}" stroke="{st}" stroke-width="{lw:.2f}"'
            pts = shape_points(geom, x, y, w, h)
            if geom == "ellipse":
                out.append(f'<ellipse cx="{x + w / 2:.1f}" cy="{y + h / 2:.1f}" rx="{w / 2:.1f}" '
                           f'ry="{h / 2:.1f}" {common}/>')
            elif geom == "roundRect":
                rr = min(w, h) * 0.1667
                out.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{rr:.1f}" {common}/>')
            elif pts:
                p = " ".join(f"{px:.1f},{py:.1f}" for px, py in pts)
                out.append(f'<polygon points="{p}" {common}/>')
            else:
                out.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" {common}/>')
            if txt:
                tx, ty = _shape_text_pos(geom, x, y, w, h, size)
                out.append(f'<text x="{tx:.1f}" y="{ty:.1f}" font-size="{size:.1f}" '
                           f'font-weight="{"bold" if bold else "normal"}" fill="{tcolor}" '
                           f'text-anchor="middle">{escape(txt)}</text>')
    out.append("</svg>")
    return "".join(out)


# --------------------------------------------------------------------------- #
# ReportLab
# --------------------------------------------------------------------------- #
def rl_font(bold, italic):
    if bold and italic:
        return "Helvetica-BoldOblique"
    if bold:
        return "Helvetica-Bold"
    if italic:
        return "Helvetica-Oblique"
    return "Helvetica"


def draw_reportlab(canv, d: Drawing, ox: float, oy_top: float, scale: float):
    """Dibuja la región en un canvas ReportLab. (ox, oy_top) = esquina sup. izq. en pt."""
    from reportlab.lib.colors import HexColor

    def X(v):
        return ox + v * scale

    def Y(v):
        return oy_top - v * scale

    canv.saveState()
    for op in d.ops:
        kind = op[0]
        if kind == "rect":
            _, x, y, w, h, fill = op
            canv.setFillColor(HexColor(fill))
            canv.rect(X(x), Y(y + h), w * scale, h * scale, stroke=0, fill=1)
        elif kind == "line":
            _, x1, y1, x2, y2, bw, color, dash = op
            canv.setStrokeColor(HexColor(color))
            canv.setLineWidth(bw * scale)
            canv.setDash([v * scale for v in dash] if dash else [])
            canv.setLineCap(2)
            canv.line(X(x1), Y(y1), X(x2), Y(y2))
        elif kind == "text":
            _, x, y, txt, size, bold, italic, color, anchor = op
            canv.setFillColor(HexColor(color))
            canv.setFont(rl_font(bold, italic), size * scale)
            if anchor == "middle":
                canv.drawCentredString(X(x), Y(y), txt)
            elif anchor == "end":
                canv.drawRightString(X(x), Y(y), txt)
            else:
                canv.drawString(X(x), Y(y), txt)
        elif kind == "shape":
            _, geom, x, y, w, h, fill, line, lw, txt, size, bold, tcolor = op
            do_fill = 1 if fill else 0
            do_stroke = 1 if line else 0
            if fill:
                canv.setFillColor(HexColor(fill))
            if line:
                canv.setStrokeColor(HexColor(line))
                canv.setLineWidth(max(0.3, lw * scale))
            canv.setDash([])
            pts = shape_points(geom, x, y, w, h)
            if geom == "ellipse":
                canv.ellipse(X(x), Y(y + h), X(x + w), Y(y), stroke=do_stroke, fill=do_fill)
            elif geom == "roundRect":
                canv.roundRect(X(x), Y(y + h), w * scale, h * scale, min(w, h) * 0.1667 * scale,
                               stroke=do_stroke, fill=do_fill)
            elif pts:
                p = canv.beginPath()
                p.moveTo(X(pts[0][0]), Y(pts[0][1]))
                for px, py in pts[1:]:
                    p.lineTo(X(px), Y(py))
                p.close()
                canv.drawPath(p, stroke=do_stroke, fill=do_fill)
            else:
                canv.rect(X(x), Y(y + h), w * scale, h * scale, stroke=do_stroke, fill=do_fill)
            if txt:
                tx, ty = _shape_text_pos(geom, x, y, w, h, size)
                canv.setFillColor(HexColor(tcolor))
                canv.setFont(rl_font(bold, False), size * scale)
                canv.drawCentredString(X(tx), Y(ty), txt)
    canv.restoreState()
